<?php
<html>
	<head>
	
	<body>
		<p>This is a para. :-) </p>
		<h6>This is a level six heading ha ha</h6>
	</body>
	
	</head>
</html>

?>